function [ data] = rga6_Boundary_2_traps_shev(launch, tau, trapCoords, epsilon, delta)
% Author: Vaibhava Srivastava

position = launch;
D = 1;
k = sqrt(D * 3 * tau);
free = 1;
step = 0; %Variable associated with finding simulated Escape time
boundaryCheck = [0,0,0];%variable associated with finding simulated Boundary time
nr1= numel(delta);
for i=1:nr1
    if (norm(position)<=1 && norm(position)>= 1-delta(i))
        boundaryCheck(i) = boundaryCheck(i) +1;
    end
end
%tic;

while (free)
    step = step + 1;
    
    displacement = k*[randn(1), randn(1), randn(1)];
    nextPosition = position + displacement;
    
    for i=1:nr1
        if (norm(position)<=1 && norm(position)>= 1-delta(i))
            boundaryCheck(i) = boundaryCheck(i) +1;
        end
    end
    
    if (norm(nextPosition) >= 1)
        if (norm(nextPosition)==1)
            
            boundaryCheck = boundaryCheck+1;
            
            P3 = nextPosition(3);
            P1 = nextPosition(1);
            
            cTheta2 = acos(P3);
            if ( (cTheta2 < epsilon ) || (cTheta2 > pi-epsilon) )
                free=1;
                break;
            end
            [reflectPos, intersect] = computeBrownianReflection(nextPosition, displacement);
            
            for i=1:nr1
                if norm(reflectPos) >= 1-delta(i) && norm(reflectPos)<= 1
                    boundaryCheck(i) = boundaryCheck(i) +1;
                end
            end
            
            nextPosition= reflectPos;
            
            
        else
            
            boundaryCheck = boundaryCheck + 1;
            
            [reflectPos, intersect] = computeBrownianReflection(nextPosition, displacement);
            for i=1:nr1
                if norm(reflectPos) >= 1-delta(i) && norm(reflectPos)<= 1
                    boundaryCheck(i) = boundaryCheck(i) +1;
                end
            end
            I3= intersect(3);
            cPhi2= acos(I3);
            if ((cPhi2 < epsilon ) || (cPhi2 > pi-epsilon))
                free=1;
                break;
            end
            
            nextPosition = reflectPos;
            
        end
    end
    
    
    position = nextPosition;
    
end

%elapsedTime = toc;
escapeTime = step*tau;
BoundaryTime1 = boundaryCheck(1)/step;
BoundaryTime2 = boundaryCheck(2)/step;
BoundaryTime3 = boundaryCheck(3)/step;
data = [ escapeTime, BoundaryTime1, BoundaryTime2, BoundaryTime3];
end

