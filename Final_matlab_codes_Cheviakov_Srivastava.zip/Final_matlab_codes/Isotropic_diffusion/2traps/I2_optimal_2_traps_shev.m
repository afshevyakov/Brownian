clear all;
close all;
clc;
filename1 = 'Boundary_Computation_two_trap_9_September_2020_10k.mat';

tau = 6e-06; % Step size
epsilon = 1e-02; %Trap size
trapCoords=[0,0,1;0 0 -1]; % Trap Coords
delta = [0.1,0.01, 0.001]; % Range of boundary parameter \delta
%Theta = 0; % Spherical coordinates \theta
Phi = [0,pi/4,pi/2,3*pi/4,pi];
r1 = [0.1,0.2,0.4,0.6,0.7,0.8,0.9];

Nr1 = numel(r1);
Nr2 = numel(Phi);
%Nr3 = numel(delta);

Nruns1pt=10000;

Nr = Nr1*Nr2;
mean_times=zeros(Nr+1,4); % The columns of the matrix are as follows: delta,x,y,z,Boundary time, Escape time
boundary_times=cell(4,4);
boundary_times_origin=cell(1,4);
L=2;
%while( l<=Nr)
%

delete(gcp)
parpool(30)

tic;
% compuations for origin
Times2pt1=zeros(Nruns1pt,1);
Times2pt2=zeros(Nruns1pt,1);
Times2pt3=zeros(Nruns1pt,1);
Times2pt4=zeros(Nruns1pt,1);
coords2pt=[0,0,0]
for k1=1: Nruns1pt
    curr_time_2 = rga6_Boundary_2_traps_shev(coords2pt, tau, trapCoords, epsilon, delta);
    Times2pt1(k1) = curr_time_2(1);
    Times2pt2(k1)= curr_time_2(2);
    Times2pt3(k1)= curr_time_2(3);
    Times2pt4(k1)= curr_time_2(4);
end
mean_times(1,1) = coords2pt(1);
mean_times(1,2) = coords2pt(2);
mean_times(1,3) = coords2pt(3);
mean_times(1,4)= mean(Times2pt1);
boundary_times(1,:) = {[coords2pt(1),coords2pt(2),coords2pt(3)], delta, mean(Times2pt1), [mean(Times2pt2), mean(Times2pt3), mean(Times2pt4)]};


%compuatations for other coordinates
for j = 1: Nr2
    curr_Phi1 = Phi(j)
    for k = 1: Nr1;
        curr_R = r1(k)
        coords1pt = [(curr_R)*sin(curr_Phi1),0,(curr_R)*cos(curr_Phi1)];
        Times1pt1=zeros(Nruns1pt,1);
        Times1pt2=zeros(Nruns1pt,1);
        Times1pt3=zeros(Nruns1pt,1);
        Times1pt4=zeros(Nruns1pt,1);
        
        parfor i1 =1:Nruns1pt
            curr_time = rga6_Boundary_2_traps_shev(coords1pt, tau, trapCoords, epsilon, delta);
            Times1pt1(i1) = curr_time(1);
            Times1pt2(i1)= curr_time(2);
            Times1pt3(i1)= curr_time(3);
            Times1pt4(i1)= curr_time(4);
            %i1
            
        end
        mean_times(L,1) = coords1pt(1);
        mean_times(L,2) = coords1pt(2);
        mean_times(L,3) = coords1pt(3);
        mean_times(L,4)= mean(Times1pt1);
        boundary_times(L,:) = {[coords1pt(1),coords1pt(2),coords1pt(3)], delta, mean(Times1pt1), [mean(Times1pt2), mean(Times1pt3), mean(Times1pt4)]};
        
        L = L+1;
    end
    toc
end
%end

% The columns of the matrix are as follows: delta,x,y,z, Escape time
mean_times

save(filename1);

delete(gcp)