clear all;
close all;
clc;
filename1 = 'Boundary_Computation_one_trap_14_August_2020_10k.mat';

tau = 6e-06; % Step size
epsilon = 1e-02; %Trap size
trapCoords=[0,0,1]; % Trap Coords
delta = [0.1,0.01, 0.001]; % Range of boundary parameter \delta
%Theta = 0; % Spherical coordinates \theta
Phi = [pi/4,pi/2,3*pi/4,pi];%[pi/4,0,7*pi/4,3*pi/2]; % Spherical coordinates \phi
r1 = [0.1,0.2,0.4,0.6,0.7,0.8,0.9];

Nr1 = numel(r1);
Nr2 = numel(Phi);
%Nr3 = numel(delta);

Nruns1pt=10000;

Nr = Nr1*Nr2;
mean_times=zeros(Nr,4); % The columns of the matrix are as follows: delta,x,y,z,Boundary time, Escape time
boundary_times=cell(4,4);
L=1;
%while( l<=Nr)

delete(gcp)
parpool(30)

tic;
for j = 1: Nr2
    curr_Phi1 = Phi(j)
    for k = 1: Nr1;
        curr_R = r1(k);
        coords1pt = [(curr_R)*cos(curr_Phi1),0,(curr_R)*sin(curr_Phi1)];
        Times1pt1=zeros(Nruns1pt,1);
        Times1pt2=zeros(Nruns1pt,1);
        Times1pt3=zeros(Nruns1pt,1);
        Times1pt4=zeros(Nruns1pt,1);
        
        parfor i1 =1:Nruns1pt
            
            
            curr_time = rga6_Boundary_2_shev(coords1pt, tau, trapCoords, epsilon, delta);
            Times1pt1(i1) = curr_time(1);
            Times1pt2(i1)= curr_time(2);
            Times1pt3(i1)= curr_time(3);
            Times1pt4(i1)= curr_time(4);
            %i1            
            
        end
        mean_times(L,1) = coords1pt(1);
        mean_times(L,2) = coords1pt(2);
        mean_times(L,3) = coords1pt(3);
        mean_times(L,4)= mean(Times1pt1);
        boundary_times(L,:) = {[coords1pt(1),coords1pt(2),coords1pt(3)], delta, mean(Times1pt1), [mean(Times1pt2), mean(Times1pt3), mean(Times1pt4)]};
        
        L = L+1;
    end
    toc
end
%end

% The columns of the matrix are as follows: delta,x,y,z, Escape time
mean_times

save(filename1);

delete(gcp)