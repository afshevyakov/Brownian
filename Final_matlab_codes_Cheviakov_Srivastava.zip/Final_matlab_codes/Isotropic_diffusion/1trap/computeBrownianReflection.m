function [ reflectPos, intersect  ] = computeBrownianReflection(position, displacement)

D = norm(displacement);
P = norm(position);
kappa = position*displacement'/D;
alpha = sqrt( 1 + kappa^2 - P^2) - kappa;
intersect = position + alpha*displacement/D;
bounce = D - norm(intersect - position);
%Rotation matrix
R = 2*[ intersect(1)^2 - 0.5, intersect(1)*intersect(2), intersect(1)*intersect(3) ; ...
    intersect(1)*intersect(2), intersect(2)^2 - 0.5, intersect(2)*intersect(3) ; ...
    intersect(1)*intersect(3), intersect(2)*intersect(3), intersect(3)^2 - 0.5];

reflectPos = intersect - (R*displacement'*bounce/D)';

end