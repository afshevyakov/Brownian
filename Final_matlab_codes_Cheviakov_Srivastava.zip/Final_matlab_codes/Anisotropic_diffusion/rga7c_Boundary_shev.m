function [R_escapeTime, R_BoundaryTimes]= rga7c_Boundary_shev(launch, tau, trapCoords, epsilon, delta, ambient_D, particle_size, boundary_factor)
% Author: Vaibhava Srivastava and Dr. Alexey

position = launch;
free = 1; % running while particle is not captured
%a = 0.01; particle_size??
step = 0; %Variable associated with finding simulated Escape time
boundaryCheck = [0,0,0];%variable associated with finding simulated Boundary time
nr1= numel(delta); % number of boundary layers we consider

a= particle_size;

boundary_layer_width=particle_size*boundary_factor;

D=ambient_D; %constant diffusivity provided
        
for i=1:nr1
    if (norm(position) + a <=1 && norm(position) + a >= 1-delta(i))
        boundaryCheck(i) = boundaryCheck(i) +1;
    end
end
%tic;

   % disp(position);
    pause(1);
%walk=position';

while (free)
    
    xn = norm(position);
    z=max(1-xn,a); %distance of our particle to the boundary
    
    %start with checking whether the current position is in any delta-region of proximity to boundary
    for i=1:nr1
        if (z<=delta(i))
            boundaryCheck(i) = boundaryCheck(i) +1;
        end
    end
    
    % compute the next position of the diffusing Brownian particle
      
    if z>=boundary_layer_width %then ignore anisotropy and boundary effects 
        k = sqrt(D * 3 * tau);
        displacement = k*[randn(1), randn(1), randn(1)];
        nextPosition = position + displacement;
    else
        q=a/z; %dimensionless small parameter in Lin paper; q=1/s; we ar in the boundary layer when s>boundary_factor
        lam_perp_m1 = 1 - (9/8)*q + (1/2)*(q)^3;
        lam_par_m1 = 1 - (9/16)*q + (1/8)*(q)^3 - (45/256)*(q)^4 - (1/16)*(q)^5;
        
        D_perp=lam_perp_m1*D;
        D_par=lam_par_m1*D;
        
        k_perp = sqrt(D_perp * 3 * tau);
        k_par = sqrt(D_par * 3 * tau);
        
        displacement1 = [randn(1), randn(1), randn(1)];
        
        unit_vec_radial=position/xn;
        
        displacement1_perp = unit_vec_radial * (unit_vec_radial*displacement1');
        
        displacement1_par = displacement1-displacement1_perp;
        
        displacement= k_perp*displacement1_perp + k_par*displacement1_par;
        
        nextPosition = position + displacement;
        
%         disp(["aniso", D_perp, D_par]);
    end

    xn_new=norm(nextPosition);

    %if the particle is neither captured nor reflected, keep going:
    
    if (xn_new>=1) %new position is on or beyond bdry: particle is reflected or trapped; recompute
%         position = nextPosition;
%         continue;
%     else %particle is close to the boundary. particle may be trapped or reflected. Compute intersection and reflcted positions

        nD = norm(displacement);
        kappa = position*displacement'/nD;
        alpha = sqrt( 1 + kappa^2 - xn^2) - kappa;
        intersection = position + alpha*displacement/nD;

        %if intersection near trap, then exit!
        if (norm(intersection-trapCoords)<=epsilon)
            free=0;
            break;
        end
        
        %otherwise continue - compute reflection
        
        bounce = nD - norm(intersection - position);
        %Rotation matrix
        R = 2*[ intersection(1)^2 - 0.5, intersection(1)*intersection(2), intersection(1)*intersection(3) ; ...
            intersection(1)*intersection(2), intersection(2)^2 - 0.5, intersection(2)*intersection(3) ; ...
            intersection(1)*intersection(3), intersection(2)*intersection(3), intersection(3)^2 - 0.5];

        %reflectPos 
        nextPosition= intersection - (R*displacement'*bounce/nD)';
        
        xn_new=norm(nextPosition);
        
    end;
    
    step = step + 1;     
    position = nextPosition;
%     disp([position, displacement, xn_new]);
%     pause(1);
%    walk=[walk, position'];
    
end

%elapsedTime = toc;
escapeTime = step*tau;
BoundaryTime1 = boundaryCheck(1)/step;
BoundaryTime2 = boundaryCheck(2)/step;
BoundaryTime3 = boundaryCheck(3)/step;

%return
R_escapeTime=escapeTime;
R_BoundaryTimes=[BoundaryTime1, BoundaryTime2, BoundaryTime3];
%R_walk= walk;
end

