clear all;
close all;
clc;

%%
tau = 6e-06; % Step size

epsilon = 1e-02; %Trap size  %epsilon = 4e-01; %Trap size  test

trapCoords=[0,0,1]; % Trap Coords
delta = [0.1,0.01, 0.001]; % Range of boundary parameter \delta

Phi = [0];

r1 = [-9:1:9]*0.1;

filename1 = 'z_axis_r_';

all_fnames=["qq"];

for ii=1:numel(r1)
   fnameii= sprintf('%s\\%s%2.1f.txt',pwd,filename1,r1(ii));
   disp(fnameii);
   %fi d = fopen( sprintf( '%s%2.1f.txt',filename1,j) );  % where j is your loop variable
   all_fnames = [all_fnames, string(fnameii)];
end
all_fnames = all_fnames(2:end);

%%

Psize=1e-3; %size of the Brownian particle
Bfactor=22.5; % at distances z>Bfactor*Psize from the boundary, the diffusivities D_perp and D_par are both >0.95 D
%so anisotropy and boundary effects can be ignored. See Lin_var_diff.mw

Dcoeff=1.0;  %constant ambient diffusivity

NR = numel(r1);
%NPhi = numel(Phi);

Nruns1pt=10000;
%Nruns1pt=10;   test

%Nr = NR*NPhi;
%mean_times=zeros(Nr,4); % The columns of the matrix are as follows: delta,x,y,z,Boundary time, Escape time
%boundary_times=cell(4,4);
%L=1;

 p = gcp('nocreate'); % If there is a nonempty pool, delete it
 if (~isempty(p))
     delete(gcp)
 end;
 parpool(30)
% parpool(2)

curr_Phi1 = Phi(1);

%%

parfor i1 =1:Nruns1pt
    for k = 1: NR
        curr_R = r1(k);
        coords1pt = [(curr_R)*sin(curr_Phi1),0,(curr_R)*cos(curr_Phi1)];
        
        [R_escapeTime, R_BoundaryTimes] = rga7c_Boundary_shev(coords1pt, tau, trapCoords, epsilon, delta, Dcoeff, Psize, Bfactor);

        fname1=all_fnames(k);
        fileID=fopen(fname1,'a+');
        fprintf(fileID, "%020.16e   %020.16e   %020.16e   %020.16e   \n", R_escapeTime, R_BoundaryTimes(1), R_BoundaryTimes(2), R_BoundaryTimes(3));
        fclose(fileID);
    end
end
% 
% 
% % The columns of the matrix are as follows: delta,x,y,z, Escape time
% mean_times
% 
% save(filename1);
% 
delete(gcp)